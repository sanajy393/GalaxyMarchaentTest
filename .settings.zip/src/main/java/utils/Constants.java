package utils;

/**
 * This class has the constant values
 *
 */
public class Constants 
{
	public static final String QUESTION_MARK = " ?";
	
	public static final String IS_VALUE = " is ";
	
	public static final String SPACE = " ";
	
	public static final String HOW ="how";
	
	public static final String HOW_MANY ="how many";

	public static final String HOW_MUCH ="how much";
	
	public static final String CREDITS ="Credits";
	
	
	
}
